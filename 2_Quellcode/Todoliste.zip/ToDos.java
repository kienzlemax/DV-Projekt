import javax.swing.JPanel;

public class ToDos extends JPanel {

	/**
	 * Create the panel.
	 */
	public ToDos() {

	}

}
